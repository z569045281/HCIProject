using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Assets.Scripts;


namespace Assets.Scripts{
public class NewBehaviourScript : MonoBehaviour
{


   
    // Start is called before the first frame update
    public void Start()
    {
        
        var test = new spatio();

        test.caculateSpatio();

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}}

